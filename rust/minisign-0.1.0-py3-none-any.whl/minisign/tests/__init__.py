"""Minisign tests."""
